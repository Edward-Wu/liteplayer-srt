package com.sls.liteplayer;
/**
 * @author zed
 * @date 2017/12/12 下午2:55
 * @desc 不支持解码时候的回调
 */

public interface OnSupportListener {

	void UnSupport();

}
