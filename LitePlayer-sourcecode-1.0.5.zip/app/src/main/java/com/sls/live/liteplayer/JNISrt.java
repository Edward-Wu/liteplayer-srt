package com.sls.live.liteplayer;

import java.io.ByteArrayInputStream;

public class JNISrt {
    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("JNISrt");
    }
    public JNISrt()
    {

    }
    //Java_com_sls_live_liteplayer_JNISrt_srtOpen

    public native int srtStartup();
    public native int srtCleanup();

//    public native long srtOpen(String url);
//    public native int srtClose(long srt);

//    public native int srtSend(long srt, byte[] data);
//    public native byte[] srtRecv(long srt);

    }
