package com.sls.liteplayer;

public class MediaDecoder {
    public boolean addESData(byte[] data, int len, long dts, long pts) {
        return true;
    }
}
