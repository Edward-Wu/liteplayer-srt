package com.sls.live.liteplayer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private final String TAG = MainActivity.class.getSimpleName();

    private JNISrt srt = new JNISrt();
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        int ret = 0;
        int sock = 0;
        String strTemp = "";
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        //ret = srt.srtStartup();
        //Log.i(TAG, "srt_startup， ret=" + ret);

        ret = srt.srtStartup();
        Log.i(TAG, "srtStartup， str=" + ret);

        strTemp = "srtStartup , str=" + ret ;

        final TextView txt = (TextView) findViewById(R.id.text_view);
        txt.setText(strTemp);

    }
}
