package com.sls.liteplayer;

/**
 * @author zed
 * @date 2017/12/12 下午2:08
 * @desc
 */

public class DataInfo {

	public byte[] mDataBytes;
	public long receivedDataTime;

}
